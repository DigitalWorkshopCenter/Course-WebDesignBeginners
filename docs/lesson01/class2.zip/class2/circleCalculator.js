export function calculateCircumference(r) {
    return Math.PI * r * 2;
}

export function calculateArea(r) {
    return Math.PI * r * r;
}
// export {calculateCircumference};
