export function calculateCircumference(r) {
    return Math.PI * r * r;
}

// export {calculateCircumference};
